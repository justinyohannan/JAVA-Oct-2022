
//WAP to remove all the vowels from the given string.

package all.string.assignments;

public class Assign3 {

	public static void main(String[] args) {
		
		String s="Justin Yohannan";
		String s1="";
        s1 = s.replaceAll("[aeiou]", "");
        System.out.println(s1);
		
	}
}
