
//WAP to demonstrate how garbage collector work when any memory is not referenced by string object.

package all.string.assignments;

public class Assign7 {

	public static void main(String[] args) {
		
		Assign7 as=new Assign7();
		//String st=new String("Justin");
		//System.out.println( st.hashCode());
		//st=null;
		as=null;
		System.gc();
		//System.out.println(st);
		System.out.println(as);
		
	}
	
	//here object of class Assign7 is eligible for garbage collector so finalize method is called
	//st is the object of String class not Assign7 class
	//So, when System.gc() invokes garbage collector it calls the finalize() method of String class in java 
	//and the overridden finalize() method of Assign7 class is not executed.
	
	@Override
    protected void finalize()
    {
        System.out.println("Finalize method is called.");
    }
}
