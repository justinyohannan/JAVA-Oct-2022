
//WAP to demonstrate how memory is allocated to string objects in memory heap and string constant pool.


package all.string.assignments;

public class Assign6 {

	public static void main(String[] args) {
		
		String s1=new String("Justin");
		String s2="Justin";
		String s3="Justin";
		
		if(s1==s2) {
			System.out.println("yes");
		}
		else if(s2==s3) {
			System.out.println("yes for case 2");
		}
		else {
			System.out.println("no");
		}
		
		
		
	}
	
}
