//Create a program in which two string is input by the user and after that user will enter index in first string where we want to insert the second string and insert the second string at that index and create a new string

package all.string.assignments;

import java.util.Scanner;

public class Assign1 {

	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		System.out.println("Please type the first string: ");
		String s1=s.nextLine();
		System.out.println("Please type the second string: ");
		String s2=s.nextLine();
		System.out.println("Please enter the index: ");
		int ind=s.nextInt();
		
		StringBuffer sb=new StringBuffer(s1);
		
		sb.insert(ind, s2);
		System.out.println("New String: "+sb);
		
		
		
		
		
	}
}
