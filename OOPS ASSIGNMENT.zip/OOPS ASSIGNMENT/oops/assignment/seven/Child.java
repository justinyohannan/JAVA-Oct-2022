package oops.assignment.seven;

public class Child extends Parent {

	void compareString(String st1, String st2) {
		
		System.out.println("In Child Class");
		if(st1.equals(st2)) {
			System.out.println("Both string are same");
		}
		else {
			System.out.println("Both String are different");
		}
	}
}
