package oops.assignment.seven;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		System.out.println("Please Enter first string");
		String st1=s.nextLine();
		System.out.println("Please Enter second string");
		String st2=s.nextLine();
		
		Parent p=new Child();
		p.compareString(st1, st2);
		
	}
}
