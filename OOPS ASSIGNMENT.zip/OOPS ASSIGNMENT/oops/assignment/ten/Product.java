package oops.assignment.ten;

public class Product implements Cloneable {

	int pid;
	String pname;
	int price;
	double unitOfMeasurement;
	
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public double getUnitOfMeasurement() {
		return unitOfMeasurement;
	}
	public void setUnitOfMeasurement(double unitOfMeasurement) {
		this.unitOfMeasurement = unitOfMeasurement;
	}
	
	public Product(int pid, String pname, int price, double unitOfMeasurement) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.price = price;
		this.unitOfMeasurement = unitOfMeasurement;
	}
	
	public Object clone() throws CloneNotSupportedException{
		return super.clone();
	}
	
	
	
	@Override
	public String toString() {
		return "Product [pid=" + pid + ", pname=" + pname + ", price=" + price + ", unitOfMeasurement="
				+ unitOfMeasurement + "]";
	}
	public static void main(String[] args) {
		
		try {
			
			Product pr1 =new Product(323432,"OnePlus",24534,23.42);
			Product pr2 = (Product)pr1.clone();
			
			pr2.pname="VIVO";
		    pr2.price=20000;
			
			System.out.println(pr1);
			System.out.println(pr2);
			System.out.println(pr1.hashCode());
			System.out.println(pr2.hashCode());
			System.out.println(pr1 instanceof Product);
			System.out.println(pr2 instanceof Product);
			
			
		
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}
	
	
	
	
	
}
