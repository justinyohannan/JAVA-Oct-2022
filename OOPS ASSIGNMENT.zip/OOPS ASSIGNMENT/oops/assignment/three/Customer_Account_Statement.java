package oops.assignment.three;

import java.time.LocalDate;

public class Customer_Account_Statement extends Customer {

		
	int caid;
	int custId;
	double amount; 
	String deposit_withdrawl;
	LocalDate deposit_date;
	public int getCaid() {
		return caid;
	}
	public void setCaid(int caid) {
		this.caid = caid;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getDeposit_withdrawl() {
		return deposit_withdrawl;
	}
	public void setDeposit_withdrawl(String deposit_withdrawl) {
		this.deposit_withdrawl = deposit_withdrawl;
	}
	public LocalDate getDeposit_date() {
		return deposit_date;
	}
	public void setDeposit_date(LocalDate deposit_date) {
		this.deposit_date = deposit_date;
	}
	@Override
	public String toString() {
		return "Customer_Account_Statement [caid=" + caid + ", custId=" + custId + ", amount=" + amount
				+ ", deposit_withdrawl=" + deposit_withdrawl + ", deposit_date=" + deposit_date + "]";
	}
	
	
	public Customer_Account_Statement(int custId, int accountno, String custname, String cust_address,
			LocalDate cust_dob, LocalDate cust_account_opening_date, Branch branch_Obj) {
		super(custId, accountno, custname, cust_address, cust_dob, cust_account_opening_date, branch_Obj);
		// TODO Auto-generated constructor stub
	}
	
	
}
