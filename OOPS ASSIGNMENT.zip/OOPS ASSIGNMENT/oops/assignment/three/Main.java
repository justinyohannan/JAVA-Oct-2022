package oops.assignment.three;

import java.time.LocalDate;

public class Main {

	public static void main(String[] args) {
		
		Branch b1=new Branch(101, "Bank2", "Palasia");
		Branch b2=new Branch(102, "Bank4", "Vijay Nagar");
		Branch b3=new Branch(103, "Bank3", "Radisson Sq.");
		Branch b4=new Branch(104, "Bank5", "Rau");
		Branch b5=new Branch(105, "Bank1", "Bhawarkua");
		
		Customer c1=new Customer(111, 10001, "Justin", "Indore", LocalDate.of(1998, 3, 24), LocalDate.of(2022, 1, 23), b1);
		Customer c2=new Customer(112, 10002, "Ram", "Indore", LocalDate.of(1998, 9, 2), LocalDate.of(2022, 1, 23), b2);
		Customer c3=new Customer(113, 10003, "Shyam", "Indore", LocalDate.of(1998, 2, 4), LocalDate.of(2022, 1, 23), b3);
		Customer c4=new Customer(114, 10004, "Mohan", "Indore", LocalDate.of(1998, 7, 20), LocalDate.of(2022, 1, 23), b4);
		Customer c5=new Customer(115, 10005, "Sandeep", "Indore", LocalDate.of(1998, 5, 12), LocalDate.of(2022, 1, 23), b5);
		
		
		System.out.println(c1);
	}
	
}
