package oops.assignment.five;

public class A extends CalAbs{
	
	void sum(int a, int b) {
		System.out.println(a+b);
	}

}
