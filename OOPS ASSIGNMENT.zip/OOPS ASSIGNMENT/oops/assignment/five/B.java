package oops.assignment.five;

public class B extends A{

	void sub(int a, int b) {
		System.out.println(a-b);
	}
}
