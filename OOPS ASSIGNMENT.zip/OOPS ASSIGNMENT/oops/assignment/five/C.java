package oops.assignment.five;

public class C extends B{

	void mul(int a, int b) {
		System.out.println(a*b);
	}
	
	public static void main(String[] args) {
		
		A a=new A();
		B b=new B();
		C c=new C();
		D d=new D();
		a.sum(23,45);
		b.sub(23, 11);
		c.mul(4, 5);
		d.div(12, 3);
		
	}
}
