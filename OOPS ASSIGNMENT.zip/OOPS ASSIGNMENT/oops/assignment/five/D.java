package oops.assignment.five;

public class D extends C{

	void div(int a, int b) {
		System.out.println(a/b);
	}
	
}
