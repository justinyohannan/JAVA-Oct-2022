package oops.assignment.one;

import java.time.LocalDate;
import java.util.Date;

public class Employee extends Person {
	
	double salary;
	LocalDate date_of_joining;
	String base_location;
	Department deptobj;
	int contactno;
	String emailid;
	

	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public LocalDate getDate_of_joining() {
		return date_of_joining;
	}
	public void setDate_of_joining(LocalDate date_of_joining) {
		this.date_of_joining = date_of_joining;
	}
	public String getBase_location() {
		return base_location;
	}
	public void setBase_location(String base_location) {
		this.base_location = base_location;
	}
	public Department getDeptobj() {
		return deptobj;
	}
	public void setDeptobj(Department deptobj) {
		this.deptobj = deptobj;
	}
	public int getContactno() {
		return contactno;
	}
	public void setContactno(int contactno) {
		this.contactno = contactno;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	
	
	
	public Employee(int pid, String name, String address, LocalDate dob, double salary, LocalDate date_of_joining,
			String base_location, Department deptobj, int contactno, String emailid) {
		super(pid, name, address, dob);
		this.salary = salary;
		this.date_of_joining = date_of_joining;
		this.base_location = base_location;
		this.deptobj = deptobj;
		this.contactno = contactno;
		this.emailid = emailid;
	}
	
	
	public Employee(int pid, String name, String address, LocalDate dob) {
		super(pid, name, address, dob);
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Employee [salary=" + salary + ", date_of_joining=" + date_of_joining + ", base_location="
				+ base_location + ", deptobj=" + deptobj + ", contactno=" + contactno + ", emailid=" + emailid + "]";
	}
	
	
	
	
	
	
	
}
