package oops.assignment.one;

import java.time.LocalDate;

public class Customer extends Person {

	LocalDate date_of_registration;
	String delivery_address;
	int contactno;
	String email_id;
	public LocalDate getDate_of_registration() {
		return date_of_registration;
	}
	public void setDate_of_registration(LocalDate date_of_registration) {
		this.date_of_registration = date_of_registration;
	}
	public String getDelivery_address() {
		return delivery_address;
	}
	public void setDelivery_address(String delivery_address) {
		this.delivery_address = delivery_address;
	}
	public int getContactno() {
		return contactno;
	}
	public void setContactno(int contactno) {
		this.contactno = contactno;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	
	public Customer(int pid, String name, String address, LocalDate dob, LocalDate date_of_registration,
			String delivery_address, int contactno, String email_id) {
		super(pid, name, address, dob);
		this.date_of_registration = date_of_registration;
		this.delivery_address = delivery_address;
		this.contactno = contactno;
		this.email_id = email_id;
	}
	@Override
	public String toString() {
		return "Customer [date_of_registration=" + date_of_registration + ", delivery_address=" + delivery_address
				+ ", contactno=" + contactno + ", email_id=" + email_id + "]";
	}
	
	
	
	
	
}
