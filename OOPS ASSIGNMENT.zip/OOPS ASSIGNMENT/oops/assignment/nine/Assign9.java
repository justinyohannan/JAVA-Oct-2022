package oops.assignment.nine;

public class Assign9 {

	public static void main(String[] args) {
		
		Assign9 as1=new Assign9();
		Assign9 as2=new Assign9();
		Assign9 as3=new Assign9();
		Assign9 as4=new Assign9();
		
		System.out.println(as1);
		System.out.println(as1.hashCode());
		System.out.println(as2.hashCode());
		System.out.println(as3.hashCode());
		System.out.println(as4.hashCode());
		
		as1=null;
		
		System.gc();
		
		System.out.println(as1);
		try {
			System.out.println(as1.hashCode());			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
	@Override
	protected void finalize() throws Throwable {
		System.out.println("Calling finalize method");
	}
}
