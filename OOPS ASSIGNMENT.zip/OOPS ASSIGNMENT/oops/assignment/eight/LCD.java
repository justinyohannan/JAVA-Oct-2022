package oops.assignment.eight;

import java.time.LocalDate;

public class LCD extends Electronics{

	public LCD(int id, String semiconductorType, LocalDate dateOfManufacturing) {
		super(id, semiconductorType, dateOfManufacturing);
		// TODO Auto-generated constructor stub
	}

}
