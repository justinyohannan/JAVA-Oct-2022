package oops.assignment.eight;

import java.time.LocalDate;

public class Electronics {

	int id;
	String semiconductorType;
	LocalDate dateOfManufacturing;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSemiconductorType() {
		return semiconductorType;
	}
	public void setSemiconductorType(String semiconductorType) {
		this.semiconductorType = semiconductorType;
	}
	public LocalDate getDateOfManufacturing() {
		return dateOfManufacturing;
	}
	public void setDateOfManufacturing(LocalDate dateOfManufacturing) {
		this.dateOfManufacturing = dateOfManufacturing;
	}
	@Override
	public String toString() {
		return "Electronics [id=" + id + ", semiconductorType=" + semiconductorType + ", dateOfManufacturing="
				+ dateOfManufacturing + "]";
	}
	public Electronics(int id, String semiconductorType, LocalDate dateOfManufacturing) {
		super();
		this.id = id;
		this.semiconductorType = semiconductorType;
		this.dateOfManufacturing = dateOfManufacturing;
	}
	
	
	
}
