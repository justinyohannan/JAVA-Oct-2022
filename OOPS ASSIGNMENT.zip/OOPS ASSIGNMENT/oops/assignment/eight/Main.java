package oops.assignment.eight;

import java.time.LocalDate;

public class Main {

	public static void main(String[] args) {
		
		Electronics e1=new Mobile(12323,"Yes",LocalDate.of(2001,12,12));
		Electronics e2=new LCD(1323,"Yes",LocalDate.of(2002,12,12));
		Electronics e3=new Laptop(1233,"Yes",LocalDate.of(2002,12,12));
		
		System.out.println(e1);
		System.out.println(e2);
		System.out.println(e3);
		
	}
}
