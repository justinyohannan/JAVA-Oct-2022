package oops.assignment.eleven;

import java.time.LocalDate;
import java.util.Date;

public class Employee1 {

	private int empid;
	private String empname, empaddress;
	private double salary;
	private Date emp_dob, emp_doj;
	
	
	
	public int getEmpid() {
		return empid;
	}



	public void setEmpid(int empid) {
		this.empid = empid;
	}



	public String getEmpname() {
		return empname;
	}



	public void setEmpname(String empname) {
		this.empname = empname;
	}



	public String getEmpaddress() {
		return empaddress;
	}



	public void setEmpaddress(String empaddress) {
		this.empaddress = empaddress;
	}



	public double getSalary() {
		return salary;
	}



	public void setSalary(double salary) {
		this.salary = salary;
	}



	public Date getEmp_dob() {
		return emp_dob;
	}



	public void setEmp_dob(Date emp_dob) {
		this.emp_dob = emp_dob;
	}



	public Date getEmp_doj() {
		return emp_doj;
	}



	public void setEmp_doj(Date emp_doj) {
		this.emp_doj = emp_doj;
	}
	

	public Employee1(int empid, String empname, String empaddress, double salary, Date emp_dob,Date emp_doj) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.empaddress = empaddress;
		this.salary = salary;
		this.emp_dob = emp_dob;
		this.emp_doj = emp_doj;
	}

	


	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empname=" + empname + ", empaddress=" + empaddress + ", salary=" + salary
				+ ", emp_dob=" + emp_dob + ", emp_doj=" + emp_doj + "]";
	}



	public static void main(String[] args) {
		Date d=new Date(2022,00,22); 
		Date d1=new Date(); 
		Employee1 emp = new Employee1(1014808, "Justin Yohannan", "Indore", 32432.00, d, d1);
		
		System.out.println(emp.toString());
		
	}
}
