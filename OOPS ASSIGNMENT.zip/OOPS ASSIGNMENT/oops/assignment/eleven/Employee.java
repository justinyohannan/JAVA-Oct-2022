
package oops.assignment.eleven;

import java.time.LocalDate;
import java.util.Date;

public class Employee {

	private int empid;
	private String empname, empaddress;
	private double salary;
	private LocalDate emp_dob, emp_doj;
	
	
	
	public int getEmpid() {
		return empid;
	}



	public void setEmpid(int empid) {
		this.empid = empid;
	}



	public String getEmpname() {
		return empname;
	}



	public void setEmpname(String empname) {
		this.empname = empname;
	}



	public String getEmpaddress() {
		return empaddress;
	}



	public void setEmpaddress(String empaddress) {
		this.empaddress = empaddress;
	}



	public double getSalary() {
		return salary;
	}



	public void setSalary(double salary) {
		this.salary = salary;
	}



	public LocalDate getEmp_dob() {
		return emp_dob;
	}



	public void setEmp_dob(LocalDate emp_dob) {
		this.emp_dob = emp_dob;
	}



	public LocalDate getEmp_doj() {
		return emp_doj;
	}



	public void setEmp_doj(LocalDate emp_doj) {
		this.emp_doj = emp_doj;
	}
	

	public Employee(int empid, String empname, String empaddress, double salary, LocalDate emp_dob, LocalDate emp_doj) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.empaddress = empaddress;
		this.salary = salary;
		this.emp_dob = emp_dob;
		this.emp_doj = emp_doj;
	}

	


	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empname=" + empname + ", empaddress=" + empaddress + ", salary=" + salary
				+ ", emp_dob=" + emp_dob + ", emp_doj=" + emp_doj + "]";
	}



	public static void main(String[] args) {
//		Date d=new Date(2022,6,22); 
//		Date d1=new Date(); 
		Employee emp = new Employee(1014808, "Justin Yohannan", "Indore", 32432.00, LocalDate.of(1998,03,24), LocalDate.of(2022,06,01));
		
		System.out.println(emp.toString());
		
	}
}
