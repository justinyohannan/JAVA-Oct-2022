
//WAP to find the LCM and HCF of array numbers.

package array.assignment;

public class Assign7 {

	public static void main(String[] args) {
		
		int[] a=new int[] {24,54,68,26,66};
		
		int temp, temp1, temp2, hcf, lcm;
		
		for(int i=0;i<a.length;i++) {
			for(int j=i+1;j<a.length;j++) {
			
				hcfLcm(a[i],a[j]);
			}
			
		}
		
	}
	
	static void hcfLcm(int a,int b) {
		
		int temp,hcf,lcm,num1,num2;
		
		num1=a;
		num2=b;
		 
		while(num2 != 0){
	    
			temp = num2;    
			num2 = num1%num2;
			num1 = temp;
	      
		}
		
		hcf = num1;
		lcm = (a*b)/hcf;
	    
		System.out.println("HCF of input numbers: "+hcf);
		System.out.println("LCM of input numbers: "+lcm);
		
	}
}
