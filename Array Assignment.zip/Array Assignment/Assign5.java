
//An Array Contain different numbers you have to find how many are even, odd, perfect and prime

package array.assignment;

public class Assign5 {

	public static void main(String[] args) {
		
		int[] a= new int[] {23,445,21,52,541,435,6,97};
		
		boolean ans = false;
		for(int i=0; i<a.length;i++) {
			
			isEvenOdd(a[i]);
			ans=isPrime(a[i]);
			isPerfect(a[i]);
		}
		System.out.println(ans);
		
	}
	
	static void isEvenOdd(int a) {
		if (a%2==0) {
			System.out.println(a+" is an even number");
		}
		else {
			System.out.println(a+" is an odd number");
		}
	}
	
	static void isPerfect(int a) {
		
		int sum=0;  
		int i=1;  

		while(i <= a/2)  {  
		
			if(a % i == 0)  
		
			{  

				sum = sum + i;  
		
			} //end of if  
		
			i++;  
		} 
		
		if(sum==a){  
			System.out.println(a+" is a perfect number.");  
		
		}  
		
		else {  
			System.out.println(a+" is not a perfect number.");   
		}
	}
	
	static boolean isPrime(int a) {
		if(a<=1) {
			System.out.println(a+" is not a prime");
			return false;
		}
		int c=2;
		while(c*c<=a) {
			if(a%c==0) {
				System.out.println(a+" is not a prime");
				return false;
			}
			c++;
		}
		System.out.println(a+" is a prime");
		return c * c > a;
	}
	
}
