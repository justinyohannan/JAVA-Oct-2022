
//WAP to remove the String which is not palindrome string from the array of String

package array.assignment;

import java.util.Arrays;

public class Assign11 {

	public static void main(String[] args) {
		
		String a[]=new String[]{"mam", "eye", "malayalam", "radar", "level","justin"};
		
		String b[]=new String[10];
		
		int x=0;
		
		
		for(int i=0;i<a.length;i++) {
			
			if(a[i].equals(isPalind(a[i]))) {
				b[x]=a[i];
				x++;
				System.out.println(a[i]);
			}
			
		}
		
		System.out.println("Array after checking: "+Arrays.toString(b));
		
	}
	
	static String isPalind(String reverse) {
		
		String temp = reverse;
		String rev = "";   
		
		for (int i = temp.length() - 1; i >= 0; i--) {
	    
			rev = rev + temp.charAt(i);
	    
		}
	    
		return rev;
		
	}
}
