
//WAP to find third maximum number from list of numbers.

package array.assignment;

import java.util.Arrays;

public class Assign1 {

	public static void main(String[] args) {
		
		int a[]=new int[] {23,324,12,423,13,53,67};
		
		Arrays.sort(a);
		
		int thmxnm=a.length;
		
		for(int i:a) {
			System.out.println(i);
		}
		
//		int thirdMaxNum=0;
//		
//		while(true) {
//			if(a.length>0) {
//				thirdMaxNum=a.length-2;
//			}
//			else{
//				break;
//			}
//		}
//		
//		System.out.println("Third Maximum Number in the Array:"+ a[thirdMaxNum-1]);
		
		System.out.println("Third Maximum Number in the Array:"+ a[thmxnm-3]);
	
		
	}
}
