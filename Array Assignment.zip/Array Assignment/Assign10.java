
//You are having array of strings. Now you have to arrange strings in array on the basis of the length of each string. Smallest string will be first and so on.

package array.assignment;

import java.util.Arrays;

public class Assign10 {

	public static void main(String[] args) {
		
		String ar[]=new String[] {"hello","my","name","is","justin","yohannan"};
		
		for(int i = 0; i<ar.length; i++ )
	    {
	      for(int j = i+1; j<ar.length; j++)
	         {
	         if(ar[i].length()>ar[j].length()){
	            String temp = ar[i];    
	            ar[i] = ar[j];
	            ar[j] = temp;
	         }
	         
	      }
	      
	   }
		
		System.out.println("After arranging strings in array on the basis of the length of each string: "+Arrays.toString(ar));
		
	}
	
}
