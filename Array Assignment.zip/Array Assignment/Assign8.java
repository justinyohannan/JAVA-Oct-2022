
//You are given a sequence of Character in the form of Array. Now you have to put all vowels and consonants together in the array.


package array.assignment;

import java.util.Arrays;

public class Assign8 {

	public static void main(String[] args) {
		
		char[] a=new char[] {'j','u','s','t','i','n'};
		
		char[] b=new char[6];
		
		int x=0;
		int y=a.length-1;
		
		for(int i=0;i<a.length;i++) {
			
			if(a[i]=='a' || a[i]=='e' || a[i]=='i' || a[i]=='o' || a[i]=='u') {
				
				b[x]=a[i];
				x++;
				
			}
			else {
				
				b[y]=a[i];
				y--;
			}

			System.out.println(Arrays.toString(b));
			
		}
		System.out.println("Final Array: "+Arrays.toString(b));
	}
}
