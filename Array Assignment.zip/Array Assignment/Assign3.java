
//WAP to create a dynamic array. Dynamic Array means when user want to input the number more than size of array it will increase the size of array without throwing exception.

package array.assignment;

import java.util.Arrays;
import java.util.Scanner;

public class Assign3 {

	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		System.out.println("Please enter the size of array:");
		int n=s.nextInt();

		int[] a=new int[n];
		
		System.out.println("Please enter the element:");
		for(int i=0;i<a.length;i++) {
			a[i]=s.nextInt();
		}
		
		System.out.println(Arrays.toString(a));
	}
}
